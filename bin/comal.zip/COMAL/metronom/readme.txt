Metronome Installation Notes                                 V1.0 (C) MacharSoft 1999
============================                                 ========================

Pack contents:
==============
  These installation notes        README.TXT
  The metronome source code       METRONOM.CML
  The compiled version            METRONOM.EXE
  An ASCII listing                METRONOM.LST
  An article on events            COMEVENT.TXT

About METRONOM
==============
As its name suggests, METRONOM.CML simulates a simple musician's
metronome, which beats at speeds from 20 beats per minute up to 200
beats per minute. It also counts bars, and the number of beats in a
bar can be altered between 1 and 8. The program is graphics-based, and
All the inputs to the program are mouse clicks. The purpose of the
program is to demonstrate the use of prioritised event handling using
two independent clock timers, one to generate the beats and the other to 
count the bars. Handling mouse clicks represents a third level of 
event handling within the program.

Requirements:
=============
  METRONOM.CML needs:
     UniCOMAL V3.11 Developers' with the TIMERS.EXE module installed.             
  METRONOM.EXE has all required modules compiled in, so should work
        from any DOS or MS-Windows installation, with or without
        UniCOMAL.
  If you want to run this Demo in a window in MS-Windows, you need at
        least 4M video RAM and a processor running at around 200 MHz. 

Installation:
=============
  Uncompress the files into a suitable directory on your hard drive.

Known problems, limitations:
============================
  Running single-tasked (full-screen) under MS-Windows 95 or 98, there
    are no obvious problems - it all works. Response to mouse button
    clicks can be very fast on fast processors.
  Running in a window in MS-Windows 98 on a 90MHz processor gave timing
    problems when beating at more than 4 to the bar.
     
